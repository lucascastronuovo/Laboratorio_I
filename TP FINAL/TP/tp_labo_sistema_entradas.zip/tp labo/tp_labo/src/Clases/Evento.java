package Clases;

import java.sql.Date;
import java.util.ArrayList;

public class Evento {
    private  int idEvento;
    private String nombre;
    private Date fecha;
    private String direccion;

    private int capacidad;
    private ArrayList<ZonaEvento> ubicaciones;
    private int entradasDisponibles;
    private  String creador;

    public Evento() {
    }

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public ArrayList<ZonaEvento> getUbicaciones() {
        return ubicaciones;
    }

    public void setUbicaciones(ArrayList ubicaciones) {
        this.ubicaciones = ubicaciones;
    }

    public String getCreador() {
        return creador;
    }

    public void setCreador(String creador) {
        this.creador = creador;
    }

    public int getEntradasDisponibles() {
        return entradasDisponibles;
    }

    public void setEntradasDisponibles(int entradasDisponibles) {
        this.entradasDisponibles = entradasDisponibles;
    }
}
