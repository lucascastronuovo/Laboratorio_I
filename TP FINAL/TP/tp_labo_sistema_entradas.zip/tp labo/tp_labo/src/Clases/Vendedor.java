package Clases;

public class Vendedor extends Usuario{
    private Evento eventoAsignado;


    public Vendedor(String usuario, String password) {
        super(usuario, password);
    }





}
