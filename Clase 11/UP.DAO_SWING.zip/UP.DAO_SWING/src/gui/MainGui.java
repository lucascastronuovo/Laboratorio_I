package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainGui {

    public static void main(String[] args) {
        /*System.out.println("Interfaces Graficas");

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JLabel jlabel = new JLabel();
        jlabel.setText("Nombre: ");
        JTextField textField = new JTextField(20);
        JButton jButton = new JButton("Guardar");
        JLabel jLabelRespuesta = new JLabel();


        JPanel panel = new JPanel();

        LayoutManager layout = new FlowLayout();
        panel.setLayout(layout);

        panel.add(jlabel);
        panel.add(textField);
        panel.add(jButton);
        panel.add(jLabelRespuesta);

        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);


        //Eventos
        ActionListener actionListener = new ClicBoton();
        jButton.addActionListener(actionListener);

        //Clases anónimas
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jLabelRespuesta.setText(textField.getText());
            }
        });


         */

        JFrame jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        PanelListaEstudiantes panelListaEstudiantes = new PanelListaEstudiantes();
        panelListaEstudiantes.armarPanelListadoEstudiantes();
        jFrame.getContentPane().add(panelListaEstudiantes);
        jFrame.pack();
        jFrame.setVisible(true);

    }
}
