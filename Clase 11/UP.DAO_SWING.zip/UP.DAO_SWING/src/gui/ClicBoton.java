package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClicBoton implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Guardando....");
    }
}
