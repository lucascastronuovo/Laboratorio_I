package com.company.service;

public class ServiceException extends Exception{

        public ServiceException(String mensaje){

            super(mensaje);
        }





}
