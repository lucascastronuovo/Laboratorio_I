package com.company;

import com.company.entidades.Profesor;
import com.company.service.ProfesorService;

public class Main {

    public static void main(String[] args) {




    }
}
