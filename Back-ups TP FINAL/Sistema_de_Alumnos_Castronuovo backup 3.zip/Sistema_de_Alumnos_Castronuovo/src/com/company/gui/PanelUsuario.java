package com.company.gui;

public class PanelUsuario {
}
