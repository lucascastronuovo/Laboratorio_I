package com.company.dao;

import com.company.entidades.Cursada;

import java.sql.*;
import java.util.ArrayList;

public class CursadaDAOH2 implements ICursadaDAO{

    String DB_JDBC_DRIVER = "org.h2.Driver";
    String DB_URL = "jdbc:h2:~/dbcastronuovo";
    String DB_USER = "sa";
    String DB_PASSWORD = "";


    @Override
    public void guardarCursada(Cursada cursada) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

            preparedStatement = connection.prepareStatement("INSERT INTO cursadas VALUES (?,?,?,?,?,?,?,?)");
            preparedStatement.setInt(1,cursada.getCodCursada());
            preparedStatement.setInt(2,cursada.getCupoMax());
            preparedStatement.setString(3, cursada.getEstudiante().getNombre()+ " " + cursada.getEstudiante().getApellido());
            preparedStatement.setFloat(4,cursada.getPrecio());
            preparedStatement.setString(5, cursada.getProfesorAsignado().getNombre() + " " + cursada.getProfesorAsignado().getApellido());
            preparedStatement.setString(6, cursada.getMateriaAsignada().getNombreMateria());
            preparedStatement.setFloat(7, cursada.getNotaParaAprobar());
            preparedStatement.setFloat(8,cursada.getNotaEstudiante());


            int i = preparedStatement.executeUpdate();

            System.out.println("Registros insertados: " + i);
        }
        catch (ClassNotFoundException e){
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        }
        catch (SQLException e1){
            e1.printStackTrace();
            throw new DAOException(e1.getMessage());
        }
        finally {
            try {
                preparedStatement.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DAOException(e.getMessage());
            }
        }
    }

    @Override
    public void modificarCursada(Cursada cursada) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE cursadas SET CUPO_MAXIMO=?,ESTUDIANTE=?,PRECIO=?,PROFESOR=?,MATERIA=?,NOTA_PARA_APROBAR=?,NOTA_ESTUDIANTE=? WHERE COD_CURSADA=?");
            preparedStatement.setInt(8,cursada.getCodCursada());
            preparedStatement.setInt(1,cursada.getCupoMax());
            preparedStatement.setString(2,cursada.getEstudiante().getNombre()+ " " + cursada.getEstudiante().getApellido());
            preparedStatement.setFloat(3,cursada.getPrecio());
            preparedStatement.setString(4, cursada.getProfesorAsignado().getNombre() + " " + cursada.getProfesorAsignado().getApellido() );
            preparedStatement.setString(5, cursada.getMateriaAsignada().getNombreMateria());
            preparedStatement.setFloat(6, cursada.getNotaParaAprobar());
            preparedStatement.setFloat(7,cursada.getNotaEstudiante());


            int i =preparedStatement.executeUpdate();

            System.out.println("Registros modificados: " + i);
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        }
        finally {
            try {
                preparedStatement.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DAOException(e.getMessage());
            }
        }
    }

    @Override
    public void eliminarCursada(int codCursada) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

            preparedStatement = connection.prepareStatement("DELETE FROM cursadas WHERE COD_CURSADA=?");
            preparedStatement.setInt(1, codCursada);


            int i =preparedStatement.executeUpdate();
            System.out.println("Registros eliminados: " + i);








        } catch (ClassNotFoundException e)  {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        }
        finally {
            try {
                preparedStatement.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DAOException(e.getMessage());
            }
        }
    }

    @Override
    public Cursada buscarCursada(int codCursada) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Cursada cursada = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT * FROM CURSADAS WHERE COD_CURSADA=?");
            preparedStatement.setInt(1, codCursada);


            ResultSet rs =preparedStatement.executeQuery();

            while (rs.next()){

                cursada = new Cursada();
                cursada.setCodCursada(rs.getInt("COD_CURSADA"));
                cursada.setCupoMax(rs.getInt("CUPO_MAXIMO"));
                cursada.getEstudiante().setNombre(rs.getString("ESTUDIANTE"));
                cursada.getEstudiante().setApellido(rs.getString("ESTUDIANTE"));
                cursada.setPrecio(rs.getFloat("PRECIO"));
                cursada.getProfesorAsignado().setNombre(rs.getString("PROFESOR"));
                cursada.getProfesorAsignado().setApellido(rs.getString("PROFESOR"));
                cursada.setNotaParaAprobar(rs.getFloat("NOTA_PARA_APROBAR"));
                cursada.setNotaEstudiante(rs.getFloat("NOTA_ESTUDIANTE"));



                System.out.println("COD_CURSADA: " + cursada.getCodCursada() + " CUPO MÁXIMO: " + cursada.getCupoMax()+ "ESTUDIANTE: " + cursada.getEstudiante().getNombre() + " " + cursada.getEstudiante().getApellido() + "PRECIO: " + cursada.getPrecio() + "PROFESOR: " + cursada.getProfesorAsignado().getNombre() + " " + cursada.getProfesorAsignado().getApellido() + "MATERIA: " + cursada.getMateriaAsignada().getNombreMateria() + "NOTA PARA APROBAR: " + cursada.getNotaParaAprobar() + "NOTA DEL ESTUDIANTE: " + cursada.getNotaEstudiante());
            }







        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        }
        finally {
            try {
                preparedStatement.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DAOException(e.getMessage());
            }
        }

        return cursada;
    }

    @Override
    public ArrayList buscarTodas() throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Cursada cursada= null;
        ArrayList cursadas = new ArrayList();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT * FROM cursadas");



            ResultSet rs =preparedStatement.executeQuery();

            while (rs.next()){

                cursada = new Cursada();
                cursada.setCodCursada(rs.getInt("COD_CURSADA"));
                cursada.setCupoMax(rs.getInt("CUPO_MAXIMO"));
                cursada.getEstudiante().setNombre(rs.getString("ESTUDIANTE"));
                cursada.getEstudiante().setApellido(rs.getString("ESTUDIANTE"));
                cursada.setPrecio(rs.getFloat("PRECIO"));
                cursada.getProfesorAsignado().setNombre(rs.getString("PROFESOR"));
                cursada.getProfesorAsignado().setApellido(rs.getString("PROFESOR"));
                cursada.setNotaParaAprobar(rs.getFloat("NOTA_PARA_APROBAR"));
                cursada.setNotaEstudiante(rs.getFloat("NOTA_ESTUDIANTE"));

                System.out.println("COD_CURSADA: " + cursada.getCodCursada() + " CUPO MÁXIMO: " + cursada.getCupoMax()+ "ESTUDIANTE: " + cursada.getEstudiante().getNombre() + " " + cursada.getEstudiante().getApellido() + "PRECIO: " + cursada.getPrecio() + "PROFESOR: " + cursada.getProfesorAsignado().getNombre() + " " + cursada.getProfesorAsignado().getApellido() + "MATERIA: " + cursada.getMateriaAsignada().getNombreMateria() + "NOTA PARA APROBAR: " + cursada.getNotaParaAprobar() + "NOTA DEL ESTUDIANTE: " + cursada.getNotaEstudiante());
                cursadas.add(cursada);
            }







        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DAOException(e.getMessage());
        }
        finally {
            try {
                preparedStatement.close();

            } catch (SQLException e) {
                e.printStackTrace();
                throw new DAOException(e.getMessage());
            }
        }

        return cursadas;
    }
}
