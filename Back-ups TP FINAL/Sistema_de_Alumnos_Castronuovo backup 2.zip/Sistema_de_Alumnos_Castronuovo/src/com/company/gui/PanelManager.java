package com.company.gui;

import com.company.entidades.Profesor;
import com.company.gui.PanelFormularioProfesor;
import com.company.gui.PanelListadoProfesores;

import javax.swing.*;

public class PanelManager {

    private PanelListadoProfesores panelListadoProfesores;
    private PanelFormularioProfesor panelFormularioProfesor;


    private JFrame frame;



    public void armarPanelManager(){

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelFormularioProfesor = new PanelFormularioProfesor();
        panelFormularioProfesor.armarPanelFormularioProfesor(this);


        panelListadoProfesores = new PanelListadoProfesores();
        panelListadoProfesores.armarPanelListadoProfesores(this);

        frame.setVisible(true);
        frame.pack();

    }


    public void mostrarFormularioProfesor(){
        panelFormularioProfesor.vaciarComponentes();
        mostrar(panelFormularioProfesor);
    }

    public void mostrarFormularioProfesor(Profesor profesor){
        panelFormularioProfesor.armarPanelFormularioProfesor(profesor);
        mostrar(panelFormularioProfesor);
    }

    public  void mostrarListadoProfesor(){
        panelListadoProfesores.refrescarListado();
        mostrar(panelListadoProfesores);
    }

    private void mostrar(JPanel panel){
        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.getContentPane().validate();
        frame.getContentPane().repaint();
        frame.pack();
    }

}
