package com.company.dao;

public class
DAOException extends Exception{


    public DAOException(String mensaje){

        super(mensaje);

    }



}
